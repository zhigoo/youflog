tinyMCE.addI18n('ch.prettify',{
	desc : 'google prettify语法高亮'
});
