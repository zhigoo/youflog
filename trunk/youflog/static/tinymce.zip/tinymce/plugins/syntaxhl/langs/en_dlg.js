tinyMCE.addI18n('en.syntaxhl_dlg',{
	title : 'Insert code using SyntaxHighlighter',
	highlight_options : 'Highlighter Options',
	paste : 'Paste Code',
	choose_lang : 'Choose Language',
	nogutter : 'No Gutter',
	light : 'Light',
	collapse : 'Collapse',
	fontsize : 'Font size',
	first_line : 'First line',
	highlight : 'Highlight'
});
