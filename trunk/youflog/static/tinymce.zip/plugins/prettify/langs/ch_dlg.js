tinyMCE.addI18n('ch.prettify_dlg',{
	title : '使用google prettify高亮代码',
	paste : '粘贴代码'
});
